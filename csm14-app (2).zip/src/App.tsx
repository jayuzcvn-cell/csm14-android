/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { TileItem, PlaybackMode } from './types';
import { INITIAL_TILES } from './data/tiles';
import { CsmLogo } from './components/CsmLogo';
import { NumberPad } from './components/NumberPad';
import { SelectedBar } from './components/SelectedBar';
import { PaceMenuDrawer } from './components/PaceMenuDrawer';
import { TheaterModal } from './components/TheaterModal';
import { extractYouTubeId } from './utils/youtube';
import { playTactileClick, playChime, playClearSound } from './utils/audio';
import { downloadAppZip } from './utils/download';
import {
  SlidersHorizontal,
  Volume2,
  VolumeX,
  Timer,
  Download,
} from 'lucide-react';

const STORAGE_TILES_KEY = 'csm14_tiles_v2';
const STORAGE_PREFS_KEY = 'csm14_prefs_v1';

export default function App() {
  // Tile state with persistence
  const [tiles, setTiles] = useState<TileItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_TILES_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length === 8) {
          return parsed;
        }
      }
    } catch {
      // Fallback
    }
    return INITIAL_TILES;
  });

  // App settings state
  const [playbackMode, setPlaybackMode] = useState<PlaybackMode>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_PREFS_KEY);
      if (saved) {
        const p = JSON.parse(saved);
        if (p.playbackMode) return p.playbackMode;
      }
    } catch {}
    return 'new_tab'; // Default: opens video in new tab as specified
  });

  const [soundEnabled, setSoundEnabled] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_PREFS_KEY);
      if (saved) {
        const p = JSON.parse(saved);
        if (typeof p.soundEnabled === 'boolean') return p.soundEnabled;
      }
    } catch {}
    return true;
  });

  const [paceIntervalSec, setPaceIntervalSec] = useState<number>(30);
  const [autoPaceEnabled, setAutoPaceEnabled] = useState<boolean>(false);

  // Active selected tile
  const [selectedCode, setSelectedCode] = useState<string | null>('11');
  const [paceMenuOpen, setPaceMenuOpen] = useState<boolean>(false);
  const [theaterTile, setTheaterTile] = useState<TileItem | null>(null);

  // Key buffer for 2-digit direct entry (e.g. typing "1" then "2")
  const keyBufferRef = useRef<string>('');
  const keyTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Save tiles to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_TILES_KEY, JSON.stringify(tiles));
    } catch {}
  }, [tiles]);

  // Save prefs to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(
        STORAGE_PREFS_KEY,
        JSON.stringify({ playbackMode, soundEnabled })
      );
    } catch {}
  }, [playbackMode, soundEnabled]);

  // Find currently selected tile object
  const activeTile = tiles.find((t) => t.code === selectedCode) || null;

  // Open external tab safely
  const openVideoInNewTab = useCallback((tile: TileItem) => {
    if (!tile.url) return;
    window.open(tile.url, '_blank', 'noopener,noreferrer');
  }, []);

  // Handle tile click (both highlight in champagne gold and open action)
  const handleTileClick = useCallback(
    (tile: TileItem) => {
      setSelectedCode(tile.code);

      // Execute designated playback action
      if (playbackMode === 'new_tab') {
        openVideoInNewTab(tile);
      } else if (playbackMode === 'theater') {
        setTheaterTile(tile);
      } else if (playbackMode === 'both') {
        openVideoInNewTab(tile);
        setTheaterTile(tile);
      }
    },
    [playbackMode, openVideoInNewTab]
  );

  // Working clear handler
  const handleClear = useCallback(() => {
    setSelectedCode(null);
  }, []);

  // Update a single tile
  const handleUpdateTile = useCallback((code: string, newUrl: string, newLabel: string) => {
    setTiles((prev) =>
      prev.map((t) => {
        if (t.code === code) {
          const videoId = extractYouTubeId(newUrl);
          return {
            ...t,
            url: newUrl,
            label: newLabel,
            videoId: videoId || t.videoId,
            subtitle: `Custom · Track ${code}`,
          };
        }
        return t;
      })
    );
  }, []);

  // Reset tiles to original prompt links
  const handleResetTiles = useCallback(() => {
    setTiles(INITIAL_TILES);
    setSelectedCode('11');
  }, []);

  // Auto-pace interval loop
  useEffect(() => {
    if (!autoPaceEnabled) return;

    const interval = setInterval(() => {
      setTiles((currentTiles) => {
        setSelectedCode((curr) => {
          const idx = currentTiles.findIndex((t) => t.code === curr);
          const nextIdx = idx >= 0 ? (idx + 1) % currentTiles.length : 0;
          const nextTile = currentTiles[nextIdx];
          if (soundEnabled) playChime();
          return nextTile.code;
        });
        return currentTiles;
      });
    }, paceIntervalSec * 1000);

    return () => clearInterval(interval);
  }, [autoPaceEnabled, paceIntervalSec, soundEnabled]);

  // Global Keyboard Navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA') return;

      const key = e.key;

      if (key === 'Escape') {
        if (theaterTile) {
          setTheaterTile(null);
          return;
        }
        if (paceMenuOpen) {
          setPaceMenuOpen(false);
          return;
        }
      }

      if (key === 'm' || key === 'M') {
        e.preventDefault();
        setPaceMenuOpen((prev) => !prev);
        if (soundEnabled) playTactileClick();
        return;
      }

      if (key === 'c' || key === 'C') {
        e.preventDefault();
        handleClear();
        if (soundEnabled) playClearSound();
        return;
      }

      if (['1', '2', '3', '4'].includes(key)) {
        if (keyTimerRef.current) clearTimeout(keyTimerRef.current);
        keyBufferRef.current += key;

        if (keyBufferRef.current.length === 2) {
          const targetCode = keyBufferRef.current;
          keyBufferRef.current = '';
          const found = tiles.find((t) => t.code === targetCode);
          if (found) {
            handleTileClick(found);
          }
        } else {
          keyTimerRef.current = setTimeout(() => {
            keyBufferRef.current = '';
          }, 1200);
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      if (keyTimerRef.current) clearTimeout(keyTimerRef.current);
    };
  }, [theaterTile, paceMenuOpen, tiles, handleTileClick, handleClear, soundEnabled]);

  return (
    <div className="min-h-screen bg-[#000000] text-neutral-100 flex flex-col justify-between selection:bg-[#f97316]/30 selection:text-[#fed7aa] font-['Inter',sans-serif] relative overflow-x-hidden">
      {/* Liquid Glass Background Caustic Lighting Effects */}
      <div className="fixed top-0 left-1/4 w-[350px] sm:w-[600px] h-[350px] sm:h-[600px] bg-gradient-to-br from-[#f97316]/14 via-[#f97316]/4 to-transparent rounded-full blur-[130px] pointer-events-none animate-fluid-1 -z-10" />
      <div className="fixed bottom-10 right-1/4 w-[300px] sm:w-[500px] h-[300px] sm:h-[500px] bg-gradient-to-tl from-white/[0.06] via-[#f97316]/5 to-transparent rounded-full blur-[120px] pointer-events-none animate-fluid-2 -z-10" />

      {/* Top Mobile-First Header Bar */}
      <header className="w-full border-b border-white/[0.08] bg-[#000000]/80 backdrop-blur-2xl sticky top-0 z-40 px-3 sm:px-6 pt-safe pb-2.5 transition-all">
        <div className="max-w-4xl mx-auto flex items-center justify-between gap-2 sm:gap-4">
          {/* Top Left: Menu Button (labeled Menu on mobile, Pace Menu on desktop) */}
          <div className="flex items-center">
            <button
              onClick={() => {
                if (soundEnabled) playTactileClick();
                setPaceMenuOpen(true);
              }}
              type="button"
              className="min-h-[40px] sm:min-h-[44px] inline-flex items-center gap-1.5 sm:gap-2 px-2.5 sm:px-4 py-1.5 sm:py-2 liquid-glass-panel rounded-xl text-neutral-200 hover:text-white border border-white/15 hover:border-[#f97316]/60 shadow-lg transition-all duration-200 cursor-pointer active:scale-95 group"
              aria-label="Open Menu"
            >
              <SlidersHorizontal className="w-4 h-4 text-[#f97316] group-hover:rotate-45 transition-transform" />
              {/* Display "Menu" on mobile, "Pace Menu" on desktop */}
              <span className="text-xs font-bold tracking-wider uppercase sm:hidden">
                Menu
              </span>
              <span className="text-xs font-bold tracking-wider uppercase hidden sm:inline">
                Pace Menu
              </span>
              <kbd className="hidden sm:inline-block px-1.5 py-0.5 text-[9px] bg-white/10 text-neutral-400 rounded font-mono">
                M
              </kbd>
            </button>
          </div>

          {/* Center: CSM 14 Emblem Logo (Both 'CSM' and '14' share the exact same Inter typeface & weight) */}
          <div className="flex items-center justify-center">
            <CsmLogo size="sm" className="sm:hidden" />
            <CsmLogo size="md" className="hidden sm:inline-flex" />
          </div>

          {/* Top Right: System, Download & Sound Quick Toggles */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            {autoPaceEnabled && (
              <div className="hidden xs:flex items-center gap-1 px-2 py-1 liquid-glass-panel border border-[#f97316]/50 rounded-lg text-[10px] font-mono text-[#fed7aa]">
                <Timer className="w-3 h-3 text-[#f97316] animate-pulse" />
                <span>{paceIntervalSec}s</span>
              </div>
            )}

            {/* Direct 1-Click ZIP Download Button */}
            <button
              onClick={() => {
                if (soundEnabled) playTactileClick();
                downloadAppZip();
              }}
              className="min-h-[40px] sm:min-h-[44px] inline-flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl liquid-glass-panel border border-[#f97316]/50 text-[#fed7aa] hover:text-white hover:border-[#f97316] text-xs font-bold transition-all active:scale-95 cursor-pointer shadow-md"
              title="Download entire app source as ZIP"
              aria-label="Download App ZIP"
            >
              <Download className="w-4 h-4 text-[#f97316]" />
              <span className="hidden xs:inline text-[11px] font-mono">ZIP</span>
            </button>

            <button
              onClick={() => {
                playTactileClick();
                setSoundEnabled((s) => !s);
              }}
              className="min-h-[40px] sm:min-h-[44px] min-w-[40px] sm:min-w-[44px] flex items-center justify-center p-2.5 text-neutral-400 hover:text-white rounded-xl liquid-glass-panel border border-white/15 hover:border-white/25 transition-all cursor-pointer active:scale-95"
              title={soundEnabled ? 'Mute Sound' : 'Enable Sound'}
              aria-label="Toggle Sound"
            >
              {soundEnabled ? (
                <Volume2 className="w-4 h-4 text-[#f97316]" />
              ) : (
                <VolumeX className="w-4 h-4 text-neutral-500" />
              )}
            </button>
          </div>
        </div>
      </header>

      {/* Main Touch-First Content Area */}
      <main className="flex-1 flex flex-col items-center justify-center px-3.5 sm:px-6 pt-4 pb-8 sm:pb-12 pb-safe max-w-4xl w-full mx-auto space-y-4 sm:space-y-6">
        {/* Study Materials Heading & Direct Download Button */}
        <div className="text-center py-0.5 sm:py-1 space-y-2.5">
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white font-['Inter',sans-serif] drop-shadow-[0_2px_10px_rgba(255,255,255,0.15)]">
            Study Materials
          </h1>
          <div>
            <button
              onClick={() => {
                if (soundEnabled) playTactileClick();
                downloadAppZip();
              }}
              type="button"
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-[#f97316]/25 to-[#f97316]/10 hover:from-[#f97316]/40 hover:to-[#f97316]/20 border border-[#f97316]/60 text-[#fed7aa] hover:text-white text-xs font-bold transition-all shadow-[0_0_20px_rgba(249,115,22,0.3)] cursor-pointer active:scale-95"
            >
              <Download className="w-4 h-4 text-[#f97316]" />
              <span>Download Complete App (.zip)</span>
            </button>
          </div>
        </div>

        {/* 8-Tile Mobile Grid: 11, 12, 21, 22, 31, 32, 41, 42 */}
        <NumberPad
          tiles={tiles}
          selectedCode={selectedCode}
          onTileClick={handleTileClick}
          onOpenTheater={(tile) => setTheaterTile(tile)}
          playbackMode={playbackMode}
          soundEnabled={soundEnabled}
        />

        {/* Selected Bar with Liquid Glass Finish, Orange Highlight, and Working Clear */}
        <SelectedBar
          selectedTile={activeTile}
          onClear={handleClear}
          onOpenNewTab={openVideoInNewTab}
          onOpenTheater={(tile) => setTheaterTile(tile)}
          soundEnabled={soundEnabled}
        />
      </main>

      {/* Pace Menu Drawer Component */}
      <PaceMenuDrawer
        isOpen={paceMenuOpen}
        onClose={() => setPaceMenuOpen(false)}
        tiles={tiles}
        onUpdateTile={handleUpdateTile}
        onResetTiles={handleResetTiles}
        playbackMode={playbackMode}
        onSetPlaybackMode={setPlaybackMode}
        soundEnabled={soundEnabled}
        onToggleSound={() => setSoundEnabled((s) => !s)}
        paceIntervalSec={paceIntervalSec}
        onSetPaceInterval={setPaceIntervalSec}
        autoPaceEnabled={autoPaceEnabled}
        onToggleAutoPace={() => setAutoPaceEnabled((a) => !a)}
        selectedCode={selectedCode}
        onSelectTile={handleTileClick}
      />

      {/* In-App Theater Video Modal */}
      <TheaterModal
        tile={theaterTile}
        onClose={() => setTheaterTile(null)}
        onOpenNewTab={openVideoInNewTab}
      />
    </div>
  );
}
