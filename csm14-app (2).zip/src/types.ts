export interface TileItem {
  code: string;
  row: number;
  col: number;
  label: string;
  url: string;
  videoId: string;
  subtitle?: string;
  customTitle?: string;
}

export type PlaybackMode = 'new_tab' | 'theater' | 'both';

export interface AppPreferences {
  playbackMode: PlaybackMode;
  soundEnabled: boolean;
  paceIntervalSec: number;
  autoPaceEnabled: boolean;
}
