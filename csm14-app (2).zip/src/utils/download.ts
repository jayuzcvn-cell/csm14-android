/**
 * Trigger reliable file download of the complete app ZIP archive
 */
export async function downloadAppZip(): Promise<void> {
  try {
    const response = await fetch('/csm14-app.zip');
    if (!response.ok) {
      throw new Error('Network response was not ok');
    }
    const blob = await response.blob();
    const blobUrl = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = blobUrl;
    link.download = 'csm14-app.zip';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(blobUrl);
  } catch {
    // Fallback direct navigation
    window.location.href = '/csm14-app.zip';
  }
}
