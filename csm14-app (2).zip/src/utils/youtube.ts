/**
 * Utility to extract YouTube video ID from various URL formats
 */
export function extractYouTubeId(url: string): string {
  if (!url) return '';
  
  // Standard watch URL: youtube.com/watch?v=DeumyOzKqgI
  const vMatch = url.match(/[?&]v=([a-zA-Z0-9_-]{11})/);
  if (vMatch && vMatch[1]) return vMatch[1];

  // Short URL: youtu.be/DeumyOzKqgI
  const shortMatch = url.match(/youtu\.be\/([a-zA-Z0-9_-]{11})/);
  if (shortMatch && shortMatch[1]) return shortMatch[1];

  // Embed URL: youtube.com/embed/DeumyOzKqgI
  const embedMatch = url.match(/youtube\.com\/embed\/([a-zA-Z0-9_-]{11})/);
  if (embedMatch && embedMatch[1]) return embedMatch[1];

  // Live URL: youtube.com/live/DeumyOzKqgI
  const liveMatch = url.match(/youtube\.com\/live\/([a-zA-Z0-9_-]{11})/);
  if (liveMatch && liveMatch[1]) return liveMatch[1];

  return '';
}

/**
 * Returns a high-res thumbnail URL for a YouTube video
 */
export function getYouTubeThumbnail(videoId: string): string {
  if (!videoId) return '';
  return `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`;
}

/**
 * Generate embed URL with privacy enhancements and autoplay
 */
export function getYouTubeEmbedUrl(videoId: string, autoplay = true): string {
  if (!videoId) return '';
  return `https://www.youtube-nocookie.com/embed/${videoId}?autoplay=${autoplay ? 1 : 0}&rel=0&modestbranding=1&enablejsapi=1`;
}
