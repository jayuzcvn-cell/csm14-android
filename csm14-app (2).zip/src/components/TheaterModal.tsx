import React from 'react';
import { TileItem } from '../types';
import { X, ExternalLink, Sparkles } from 'lucide-react';
import { getYouTubeEmbedUrl } from '../utils/youtube';

interface TheaterModalProps {
  tile: TileItem | null;
  onClose: () => void;
  onOpenNewTab: (tile: TileItem) => void;
}

export const TheaterModal: React.FC<TheaterModalProps> = ({
  tile,
  onClose,
  onOpenNewTab,
}) => {
  if (!tile) return null;

  const embedUrl = getYouTubeEmbedUrl(tile.videoId, true);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-6 bg-black/85 backdrop-blur-xl animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-4xl bg-[#000000]/95 border border-white/20 rounded-2xl sm:rounded-3xl shadow-[inset_0_1.5px_2px_rgba(255,255,255,0.25),0_25px_60px_rgba(0,0,0,0.95)] overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top bar of modal with mobile touch buttons */}
        <div className="flex items-center justify-between px-4 sm:px-6 py-3.5 border-b border-white/10 bg-[#060608]/90 backdrop-blur-md">
          <div className="flex items-center gap-3 min-w-0">
            <span className="flex items-center justify-center w-9 h-9 rounded-xl bg-gradient-to-br from-[#fed7aa] to-[#f97316] text-black font-extrabold text-sm font-['Inter'] shadow-md shrink-0">
              {tile.code}
            </span>
            <div className="min-w-0">
              <h3 className="text-sm font-bold text-white truncate flex items-center gap-1.5">
                {tile.label}
              </h3>
              <p className="text-[11px] text-neutral-400 truncate">
                Tile {tile.code} · Study Stream
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => onOpenNewTab(tile)}
              className="min-h-[44px] inline-flex items-center gap-1.5 px-3.5 py-2 bg-white/10 hover:bg-[#f97316] text-neutral-200 hover:text-black rounded-xl text-xs font-semibold transition-all cursor-pointer active:scale-95 border border-white/15"
              title="Open directly in YouTube"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span className="hidden xs:inline">YouTube Tab</span>
            </button>

            <button
              onClick={onClose}
              className="min-h-[44px] min-w-[44px] flex items-center justify-center p-2 text-neutral-400 hover:text-white rounded-xl hover:bg-white/10 transition-colors cursor-pointer"
              title="Close Theater"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Video Player Container */}
        <div className="relative w-full aspect-video bg-black flex items-center justify-center">
          {tile.videoId ? (
            <iframe
              src={embedUrl}
              title={tile.label}
              className="w-full h-full border-0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
              allowFullScreen
            />
          ) : (
            <div className="text-center p-8 text-neutral-400">
              <p>No valid YouTube video stream available.</p>
              <p className="text-xs text-neutral-500 mt-2 font-mono">{tile.url}</p>
            </div>
          )}
        </div>

        {/* Bottom bar */}
        <div className="px-4 sm:px-6 py-3 border-t border-white/10 bg-[#060608]/90 flex items-center justify-between text-xs text-neutral-400">
          <div className="flex items-center gap-2 text-neutral-400">
            <Sparkles className="w-3.5 h-3.5 text-[#f97316]" />
            <span>Liquid Glass Cinema</span>
          </div>
          <span className="text-[11px] font-mono text-neutral-500">
            Tap outside or close
          </span>
        </div>
      </div>
    </div>
  );
};
