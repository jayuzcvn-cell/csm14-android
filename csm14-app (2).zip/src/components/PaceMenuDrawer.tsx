import React, { useState } from 'react';
import { TileItem, PlaybackMode } from '../types';
import {
  X,
  Sliders,
  Volume2,
  VolumeX,
  ExternalLink,
  MonitorPlay,
  Play,
  RotateCcw,
  Timer,
  Keyboard,
  Link,
  Save,
  CheckCircle2,
  Download,
} from 'lucide-react';
import { extractYouTubeId } from '../utils/youtube';
import { playTactileClick } from '../utils/audio';
import { downloadAppZip } from '../utils/download';

interface PaceMenuDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  tiles: TileItem[];
  onUpdateTile: (code: string, newUrl: string, newLabel: string) => void;
  onResetTiles: () => void;
  playbackMode: PlaybackMode;
  onSetPlaybackMode: (mode: PlaybackMode) => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
  paceIntervalSec: number;
  onSetPaceInterval: (seconds: number) => void;
  autoPaceEnabled: boolean;
  onToggleAutoPace: () => void;
  selectedCode: string | null;
  onSelectTile: (tile: TileItem) => void;
}

export const PaceMenuDrawer: React.FC<PaceMenuDrawerProps> = ({
  isOpen,
  onClose,
  tiles,
  onUpdateTile,
  onResetTiles,
  playbackMode,
  onSetPlaybackMode,
  soundEnabled,
  onToggleSound,
  paceIntervalSec,
  onSetPaceInterval,
  autoPaceEnabled,
  onToggleAutoPace,
  selectedCode,
  onSelectTile,
}) => {
  const [editingCode, setEditingCode] = useState<string | null>(null);
  const [editUrl, setEditUrl] = useState('');
  const [editLabel, setEditLabel] = useState('');
  const [saveSuccess, setSaveSuccess] = useState(false);

  if (!isOpen) return null;

  const handleStartEdit = (tile: TileItem) => {
    if (soundEnabled) playTactileClick();
    setEditingCode(tile.code);
    setEditUrl(tile.url);
    setEditLabel(tile.label);
  };

  const handleSaveEdit = (code: string) => {
    if (!editUrl.trim()) return;
    if (soundEnabled) playTactileClick();
    onUpdateTile(code, editUrl.trim(), editLabel.trim() || `Tile ${code}`);
    setEditingCode(null);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/80 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      />

      {/* Drawer Body (Left Sidebar / Mobile Bottom Sheet style) */}
      <div className="relative w-full sm:max-w-md bg-[#000000]/95 backdrop-blur-2xl border-r border-white/10 h-full overflow-y-auto shadow-2xl flex flex-col z-10 text-neutral-200 pb-safe">
        {/* Mobile top grab handle */}
        <div className="sm:hidden w-12 h-1 bg-white/20 rounded-full mx-auto my-2 shrink-0" />

        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-white/10 bg-[#08080a]/90 backdrop-blur-md sticky top-0 z-10">
          <div className="flex items-center gap-3">
            <span className="p-2.5 bg-[#f97316]/20 text-[#fed7aa] rounded-xl border border-[#f97316]/40 shadow-[0_0_12px_rgba(249,115,22,0.3)]">
              <Sliders className="w-4 h-4" />
            </span>
            <div>
              <h2 className="text-base font-bold text-white tracking-wide font-['Inter',sans-serif]">Pace Menu</h2>
              <p className="text-xs text-neutral-400">Settings & Playback Target</p>
            </div>
          </div>
          <button
            onClick={() => {
              if (soundEnabled) playTactileClick();
              onClose();
            }}
            className="min-h-[44px] min-w-[44px] flex items-center justify-center p-2 text-neutral-400 hover:text-white rounded-xl hover:bg-white/10 transition-colors cursor-pointer"
            aria-label="Close menu"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 space-y-6 flex-1">
          {/* Section 1: Playback Action */}
          <div className="space-y-2.5">
            <label className="text-xs font-semibold uppercase tracking-wider text-neutral-400 flex items-center gap-2">
              <MonitorPlay className="w-3.5 h-3.5 text-[#f97316]" />
              Tile Click Action
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => {
                  if (soundEnabled) playTactileClick();
                  onSetPlaybackMode('new_tab');
                }}
                className={`flex flex-col items-start p-3 rounded-xl border text-xs text-left transition-all cursor-pointer ${
                  playbackMode === 'new_tab'
                    ? 'bg-[#f97316]/15 border-[#f97316] text-white'
                    : 'bg-[#121215] border-neutral-800 text-neutral-400 hover:border-neutral-700'
                }`}
              >
                <div className="flex items-center gap-1.5 font-bold mb-1">
                  <ExternalLink className="w-3.5 h-3.5 text-[#f97316]" />
                  <span>New Tab</span>
                </div>
                <span className="text-[11px] text-neutral-400">
                  Opens YouTube in a fresh browser tab
                </span>
              </button>

              <button
                type="button"
                onClick={() => {
                  if (soundEnabled) playTactileClick();
                  onSetPlaybackMode('theater');
                }}
                className={`flex flex-col items-start p-3 rounded-xl border text-xs text-left transition-all cursor-pointer ${
                  playbackMode === 'theater'
                    ? 'bg-[#f97316]/15 border-[#f97316] text-white'
                    : 'bg-[#121215] border-neutral-800 text-neutral-400 hover:border-neutral-700'
                }`}
              >
                <div className="flex items-center gap-1.5 font-bold mb-1">
                  <Play className="w-3.5 h-3.5 text-[#f97316]" />
                  <span>Theater Modal</span>
                </div>
                <span className="text-[11px] text-neutral-400">
                  Plays in-app dark cinema window
                </span>
              </button>
            </div>
          </div>

          {/* Section 2: Pace Automation & Cadence */}
          <div className="space-y-3 p-4 rounded-xl bg-[#111114] border border-neutral-800/80">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold uppercase tracking-wider text-neutral-300 flex items-center gap-2">
                <Timer className="w-3.5 h-3.5 text-[#f97316]" />
                Auto-Pace Cycle
              </label>
              <button
                type="button"
                onClick={() => {
                  if (soundEnabled) playTactileClick();
                  onToggleAutoPace();
                }}
                className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors cursor-pointer ${
                  autoPaceEnabled ? 'bg-[#f97316]' : 'bg-neutral-700'
                }`}
              >
                <span
                  className={`inline-block h-3.5 w-3.5 transform rounded-full bg-black transition-transform ${
                    autoPaceEnabled ? 'translate-x-4.5' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>
            <p className="text-[11px] text-neutral-400">
              When active, periodically steps through tiles 11 &rarr; 42 to keep tempo.
            </p>

            <div className="space-y-1.5 pt-1">
              <div className="flex justify-between text-xs text-neutral-400">
                <span>Cadence Interval:</span>
                <span className="font-mono text-[#fed7aa] font-bold">{paceIntervalSec}s</span>
              </div>
              <input
                type="range"
                min="10"
                max="120"
                step="5"
                value={paceIntervalSec}
                onChange={(e) => onSetPaceInterval(Number(e.target.value))}
                className="w-full accent-[#f97316] bg-neutral-800 rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-neutral-600 font-mono">
                <span>10s (Rapid)</span>
                <span>60s (Standard)</span>
                <span>120s (Extended)</span>
              </div>
            </div>
          </div>

          {/* Section 3: Audio & Haptic Feedback */}
          <div className="flex items-center justify-between p-3.5 bg-[#111114] border border-neutral-800 rounded-xl">
            <div className="flex items-center gap-3">
              {soundEnabled ? (
                <Volume2 className="w-4 h-4 text-[#f97316]" />
              ) : (
                <VolumeX className="w-4 h-4 text-neutral-500" />
              )}
              <div>
                <p className="text-xs font-semibold text-white">Audio & Click Haptics</p>
                <p className="text-[11px] text-neutral-400">Tactile chime synthesizer</p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => {
                playTactileClick();
                onToggleSound();
              }}
              className={`px-3 py-1 text-xs font-semibold rounded-lg border transition-colors cursor-pointer ${
                soundEnabled
                  ? 'bg-[#f97316]/20 border-[#f97316]/50 text-[#fed7aa]'
                  : 'bg-neutral-800 border-neutral-700 text-neutral-400'
              }`}
            >
              {soundEnabled ? 'Enabled' : 'Muted'}
            </button>
          </div>

          {/* Section 4: Tile Links Directory & Editor */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold uppercase tracking-wider text-neutral-400 flex items-center gap-2">
                <Link className="w-3.5 h-3.5 text-[#f97316]" />
                Assigned Video Links ({tiles.length})
              </label>
              {saveSuccess && (
                <span className="text-[11px] text-emerald-400 flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" /> Saved!
                </span>
              )}
            </div>

            <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
              {tiles.map((tile) => {
                const isEditing = editingCode === tile.code;
                const isSelected = selectedCode === tile.code;

                return (
                  <div
                    key={tile.code}
                    className={`p-2.5 rounded-lg border text-xs transition-colors ${
                      isSelected
                        ? 'border-[#f97316]/70 bg-[#1a0f07]'
                        : 'border-neutral-800/80 bg-[#101013]'
                    }`}
                  >
                    {isEditing ? (
                      <div className="space-y-2 pt-1">
                        <div className="flex items-center justify-between font-mono font-bold text-[#f97316]">
                          <span>Edit Tile {tile.code}</span>
                          <button
                            onClick={() => setEditingCode(null)}
                            className="text-neutral-500 hover:text-white"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                        <input
                          type="text"
                          value={editLabel}
                          onChange={(e) => setEditLabel(e.target.value)}
                          placeholder="Title / Track Name"
                          className="w-full px-2 py-1 bg-black border border-neutral-700 rounded text-xs text-white"
                        />
                        <input
                          type="text"
                          value={editUrl}
                          onChange={(e) => setEditUrl(e.target.value)}
                          placeholder="https://www.youtube.com/watch?v=..."
                          className="w-full px-2 py-1 bg-black border border-neutral-700 rounded text-xs text-white"
                        />
                        <div className="flex justify-end gap-2">
                          <button
                            type="button"
                            onClick={() => handleSaveEdit(tile.code)}
                            className="inline-flex items-center gap-1 px-3 py-1 bg-[#f97316] text-black font-bold rounded text-xs cursor-pointer"
                          >
                            <Save className="w-3 h-3" /> Save Link
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="flex items-center justify-between gap-2">
                        <div
                          onClick={() => {
                            if (soundEnabled) playTactileClick();
                            onSelectTile(tile);
                          }}
                          className="cursor-pointer flex items-center gap-2.5 min-w-0 flex-1"
                        >
                          <span className="font-extrabold text-sm text-[#fed7aa] font-['Inter'] w-6">
                            {tile.code}
                          </span>
                          <div className="min-w-0">
                            <p className="font-medium text-white truncate">{tile.label}</p>
                            <p className="text-[10px] text-neutral-500 truncate">
                              Configured Video Stream
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            type="button"
                            onClick={() => handleStartEdit(tile)}
                            className="px-2 py-1 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 rounded text-[11px] cursor-pointer"
                          >
                            Edit
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            <button
              type="button"
              onClick={() => {
                if (soundEnabled) playTactileClick();
                onResetTiles();
              }}
              className="inline-flex items-center gap-1.5 text-xs text-neutral-400 hover:text-neutral-200 cursor-pointer pt-1"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Reset all 8 links to defaults</span>
            </button>
          </div>

          {/* Section 5: Export Options (Universal ZIP & Single-File Portable) */}
          <div className="p-4 rounded-xl bg-gradient-to-br from-[#f97316]/20 via-[#16120e] to-[#0d0d10] border border-[#f97316]/50 shadow-lg text-xs space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-bold text-white flex items-center gap-2 text-sm">
                <Download className="w-4 h-4 text-[#f97316]" />
                Export Project
              </span>
              <span className="text-[10px] bg-[#f97316]/25 text-[#fed7aa] px-2 py-0.5 rounded-full font-mono border border-[#f97316]/40">
                Universal Format
              </span>
            </div>
            
            <p className="text-[11px] text-neutral-300">
              Universal PKZip compatible with Windows Explorer, macOS, iOS Files app, and Android.
            </p>

            <div className="space-y-2">
              <button
                onClick={() => {
                  if (soundEnabled) playTactileClick();
                  downloadAppZip();
                }}
                type="button"
                className="w-full min-h-[44px] flex items-center justify-center gap-2 py-2.5 px-4 bg-gradient-to-r from-[#f97316] to-[#ea580c] hover:from-[#ff8a2b] hover:to-[#f97316] text-black font-extrabold rounded-xl text-xs transition-all shadow-[0_2px_14px_rgba(249,115,22,0.45)] cursor-pointer active:scale-95"
              >
                <Download className="w-4 h-4" />
                <span>Download Universal ZIP (.zip)</span>
              </button>

              <a
                href="/csm14-portable.html"
                download="csm14-portable.html"
                className="w-full min-h-[44px] flex items-center justify-center gap-2 py-2.5 px-4 bg-white/10 hover:bg-white/15 text-white font-bold rounded-xl text-xs transition-all border border-white/15 cursor-pointer active:scale-95 text-center no-underline"
              >
                <span>Download Portable HTML (Zero Install)</span>
              </a>
            </div>

            <p className="text-[10px] text-neutral-400">
              💡 <em>Portable HTML runs immediately with a double-click on any device without unzipping.</em>
            </p>
          </div>

          {/* Section 6: Keyboard Shortcuts Guide */}
          <div className="p-3.5 rounded-xl bg-[#0f0f12] border border-neutral-800/60 text-xs space-y-2">
            <div className="flex items-center gap-1.5 font-semibold text-neutral-300">
              <Keyboard className="w-3.5 h-3.5 text-[#f97316]" />
              <span>Keyboard Controls</span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-[11px] font-mono text-neutral-400">
              <div>
                <kbd className="px-1.5 py-0.5 bg-neutral-800 rounded text-white mr-1.5">11</kbd>–
                <kbd className="px-1.5 py-0.5 bg-neutral-800 rounded text-white ml-1.5">42</kbd>
                <span className="block text-[10px] text-neutral-500 mt-0.5">Quick jump</span>
              </div>
              <div>
                <kbd className="px-1.5 py-0.5 bg-neutral-800 rounded text-white mr-1.5">C</kbd>
                <span>Clear</span>
              </div>
              <div>
                <kbd className="px-1.5 py-0.5 bg-neutral-800 rounded text-white mr-1.5">M</kbd>
                <span>Pace Menu</span>
              </div>
              <div>
                <kbd className="px-1.5 py-0.5 bg-neutral-800 rounded text-white mr-1.5">Esc</kbd>
                <span>Close modal</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-neutral-800/80 bg-[#0c0c0f] text-center text-[11px] text-neutral-500">
          CSM 14 · Study Materials Controller
        </div>
      </div>
    </div>
  );
};
