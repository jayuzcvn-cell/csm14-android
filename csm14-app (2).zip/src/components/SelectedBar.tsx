import React, { useState } from 'react';
import { TileItem } from '../types';
import { ExternalLink, Play, X, Copy, Check, Sparkles } from 'lucide-react';
import { playTactileClick, playClearSound } from '../utils/audio';

interface SelectedBarProps {
  selectedTile: TileItem | null;
  onClear: () => void;
  onOpenNewTab: (tile: TileItem) => void;
  onOpenTheater: (tile: TileItem) => void;
  soundEnabled: boolean;
}

export const SelectedBar: React.FC<SelectedBarProps> = ({
  selectedTile,
  onClear,
  onOpenNewTab,
  onOpenTheater,
  soundEnabled,
}) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    if (!selectedTile) return;
    if (soundEnabled) playTactileClick();
    navigator.clipboard.writeText(selectedTile.url).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const handleClearClick = () => {
    if (soundEnabled) playClearSound();
    onClear();
  };

  const handleOpenTab = () => {
    if (!selectedTile) return;
    if (soundEnabled) playTactileClick();
    onOpenNewTab(selectedTile);
  };

  const handleOpenTheater = () => {
    if (!selectedTile) return;
    if (soundEnabled) playTactileClick();
    onOpenTheater(selectedTile);
  };

  if (!selectedTile) {
    return (
      <div className="w-full max-w-4xl mx-auto px-5 py-3.5 liquid-glass-panel rounded-2xl flex items-center justify-between text-xs text-neutral-400 transition-all">
        <div className="flex items-center gap-2.5">
          <span className="w-2 h-2 rounded-full bg-white/20 shadow-[0_0_6px_rgba(255,255,255,0.3)]" />
          <span className="tracking-wide text-neutral-300">Ready · No code tile currently selected</span>
        </div>
        <span className="hidden sm:inline-block text-neutral-500 font-mono text-[11px]">
          Tap any button (11 · 12 · 21 · 22 · 31 · 32 · 41 · 42)
        </span>
      </div>
    );
  }

  return (
    <div className="w-full max-w-4xl mx-auto px-5 py-3.5 liquid-glass-panel rounded-2xl !border-[#f97316]/80 shadow-[inset_0_1.5px_2px_rgba(254,215,170,0.45),0_0_35px_rgba(249,115,22,0.3),0_20px_45px_rgba(0,0,0,0.9)] flex flex-wrap items-center justify-between gap-3.5 transition-all animate-in fade-in duration-300 relative overflow-hidden">
      {/* Top Glass Specular Curve */}
      <div className="absolute inset-x-0 top-0 h-[45%] bg-gradient-to-b from-white/[0.12] to-transparent pointer-events-none rounded-t-2xl" />

      {/* Left: Glass Code Badge and Title */}
      <div className="relative z-10 flex items-center gap-3.5 min-w-0">
        <div className="flex items-center justify-center w-12 h-12 rounded-xl bg-gradient-to-br from-[#fed7aa] via-[#f97316] to-[#c2410c] text-black font-extrabold text-2xl shadow-[0_4px_16px_rgba(249,115,22,0.45),inset_0_1px_1px_rgba(255,255,255,0.6)] shrink-0 font-['Inter',sans-serif]">
          {selectedTile.code}
        </div>
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <span className="text-[10px] uppercase font-bold tracking-wider text-[#f97316] flex items-center gap-1">
              <Sparkles className="w-3 h-3" />
              Active Selection
            </span>
            <span className="text-neutral-500 text-xs hidden sm:inline">·</span>
            <span className="text-neutral-400 text-xs hidden sm:inline truncate max-w-[200px]">
              Tile {selectedTile.code}
            </span>
          </div>
          <p className="text-sm font-semibold text-white truncate max-w-[260px] sm:max-w-md drop-shadow-[0_1px_2px_rgba(0,0,0,0.8)]">
            {selectedTile.label}
          </p>
        </div>
      </div>

      {/* Right: Liquid Glass Actions */}
      <div className="relative z-10 flex items-center gap-2 shrink-0 ml-auto sm:ml-0">
        <button
          onClick={handleOpenTab}
          className="inline-flex items-center gap-1.5 px-4 py-2 bg-gradient-to-b from-[#fed7aa] to-[#f97316] hover:from-[#ffedd5] hover:to-[#ea580c] text-black text-xs font-bold rounded-xl transition-all shadow-[0_2px_14px_rgba(249,115,22,0.4),inset_0_1px_1px_rgba(255,255,255,0.6)] cursor-pointer active:scale-95"
          title="Open in new YouTube tab"
        >
          <ExternalLink className="w-3.5 h-3.5" />
          <span>Open Tab</span>
        </button>

        <button
          onClick={handleOpenTheater}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-white/[0.08] hover:bg-white/[0.14] text-neutral-200 hover:text-white text-xs font-medium rounded-xl border border-white/15 hover:border-white/25 shadow-[inset_0_1px_1px_rgba(255,255,255,0.2)] transition-all cursor-pointer backdrop-blur-md active:scale-95"
          title="Watch inside app theater modal"
        >
          <Play className="w-3.5 h-3.5 text-[#f97316]" />
          <span className="hidden sm:inline">Theater</span>
        </button>

        <button
          onClick={handleCopy}
          className="p-2 bg-white/[0.08] hover:bg-white/[0.14] text-neutral-300 hover:text-white rounded-xl border border-white/15 hover:border-white/25 shadow-[inset_0_1px_1px_rgba(255,255,255,0.2)] transition-all cursor-pointer backdrop-blur-md active:scale-95"
          title="Copy video link"
        >
          {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
        </button>

        {/* Working Clear button */}
        <button
          onClick={handleClearClick}
          className="inline-flex items-center gap-1 px-3 py-2 bg-white/[0.05] hover:bg-red-500/20 text-neutral-400 hover:text-red-300 text-xs font-medium rounded-xl border border-white/10 hover:border-red-500/30 transition-all cursor-pointer backdrop-blur-md active:scale-95"
          title="Clear active selection"
        >
          <X className="w-3.5 h-3.5" />
          <span>Clear</span>
        </button>
      </div>
    </div>
  );
};
