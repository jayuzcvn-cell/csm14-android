import React from 'react';
import { TileItem, PlaybackMode } from '../types';
import { playTactileClick, playChime } from '../utils/audio';

interface NumberPadProps {
  tiles: TileItem[];
  selectedCode: string | null;
  onTileClick: (tile: TileItem) => void;
  onOpenTheater: (tile: TileItem) => void;
  playbackMode: PlaybackMode;
  soundEnabled: boolean;
}

export const NumberPad: React.FC<NumberPadProps> = ({
  tiles,
  selectedCode,
  onTileClick,
  onOpenTheater: _onOpenTheater,
  playbackMode: _playbackMode,
  soundEnabled,
}) => {
  const handleClick = (tile: TileItem, e: React.MouseEvent) => {
    e.preventDefault();
    if (soundEnabled) {
      if (selectedCode === tile.code) {
        playTactileClick();
      } else {
        playChime();
      }
    }
    onTileClick(tile);
  };

  return (
    <div className="w-full max-w-4xl mx-auto">
      {/* 8 Buttons in a structured liquid glass matrix:
          Row 1: 11, 12
          Row 2: 21, 22
          Row 3: 31, 32
          Row 4: 41, 42
      */}
      <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-4 gap-3.5 sm:gap-5">
        {tiles.map((tile) => {
          const isSelected = selectedCode === tile.code;

          return (
            <button
              key={tile.code}
              onClick={(e) => handleClick(tile, e)}
              type="button"
              className={`group relative flex items-center justify-center p-6 sm:p-8 min-h-[105px] sm:min-h-[135px] rounded-2xl transition-all duration-300 cursor-pointer select-none outline-none overflow-hidden ${
                isSelected
                  ? 'liquid-glass-tile-active scale-[1.025]'
                  : 'liquid-glass-tile hover:scale-[1.015] active:scale-[0.98]'
              }`}
            >
              {/* Liquid Glass Upper Specular Reflection Curve */}
              <div
                className={`absolute inset-x-0 top-0 h-[48%] pointer-events-none rounded-t-2xl transition-opacity duration-300 ${
                  isSelected
                    ? 'bg-gradient-to-b from-[#ff8a2b]/30 to-transparent opacity-95'
                    : 'bg-gradient-to-b from-white/[0.14] to-transparent opacity-60 group-hover:opacity-100'
                }`}
              />

              {/* Refractive Top Edge Hairline */}
              <div
                className={`absolute inset-x-4 top-0 h-[1px] pointer-events-none transition-colors duration-300 ${
                  isSelected
                    ? 'bg-gradient-to-r from-transparent via-[#fed7aa]/90 to-transparent'
                    : 'bg-gradient-to-r from-transparent via-white/40 to-transparent group-hover:via-white/70'
                }`}
              />

              {/* Centered Large Code Number with Glass Refraction Depth */}
              <span
                className={`relative z-10 text-4xl sm:text-6xl font-extrabold tracking-tight transition-all duration-200 font-['Inter',sans-serif] ${
                  isSelected
                    ? 'text-[#fed7aa] drop-shadow-[0_4px_16px_rgba(249,115,22,0.7)] scale-105'
                    : 'text-white/95 group-hover:text-white drop-shadow-[0_3px_8px_rgba(0,0,0,0.9)] group-hover:scale-105'
                }`}
              >
                {tile.code}
              </span>

              {/* Top-Right Liquid Dewdrop Indicator */}
              <div className="absolute top-3.5 right-3.5 z-10">
                <span
                  className={`inline-block w-2 h-2 rounded-full transition-all duration-300 ${
                    isSelected
                      ? 'bg-[#f97316] shadow-[0_0_10px_#f97316]'
                      : 'bg-white/20 group-hover:bg-white/40 shadow-[inset_0_0.5px_1px_rgba(255,255,255,0.4)]'
                  }`}
                />
              </div>

              {/* Bottom Fluid Glow Line on Selected */}
              {isSelected ? (
                <div className="absolute inset-x-5 bottom-0 h-1 bg-gradient-to-r from-transparent via-[#f97316] to-transparent rounded-full shadow-[0_0_12px_#f97316]" />
              ) : (
                <div className="absolute inset-x-5 bottom-0 h-[1px] bg-white/[0.06] group-hover:bg-white/[0.18] transition-colors" />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};
