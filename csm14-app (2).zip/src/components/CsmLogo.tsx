import React from 'react';

interface CsmLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  showSubtitle?: boolean;
}

export const CsmLogo: React.FC<CsmLogoProps> = ({
  className = '',
  size = 'md',
  showSubtitle = false,
}) => {
  const sizeClasses = {
    sm: 'px-3.5 py-1.5 text-base',
    md: 'px-6 py-2.5 text-xl sm:text-2xl',
    lg: 'px-8 py-4 text-3xl sm:text-4xl',
  };

  return (
    <div className={`inline-flex flex-col items-center ${className}`}>
      {/* Liquid Glass Obsidian Emblem with pure black background and white Inter font CSM 14 */}
      <div
        className={`relative flex items-center justify-center bg-black border border-white/20 rounded-2xl shadow-[inset_0_1.5px_2px_rgba(255,255,255,0.3),inset_0_-1px_2px_rgba(0,0,0,0.8),0_15px_35px_rgba(0,0,0,0.95)] backdrop-blur-2xl transition-all duration-300 hover:border-[#f97316]/70 hover:shadow-[inset_0_1.5px_2px_rgba(255,255,255,0.4),0_0_25px_rgba(249,115,22,0.35)] group overflow-hidden ${sizeClasses[size]}`}
        style={{ fontFamily: "'Inter', sans-serif" }}
      >
        {/* Liquid Glass Upper Curved Sheen */}
        <div className="absolute inset-x-0 top-0 h-1/2 bg-gradient-to-b from-white/[0.16] to-transparent pointer-events-none rounded-t-2xl" />

        {/* Specular Edge Refraction Line */}
        <div className="absolute inset-x-3 top-0 h-[1px] bg-gradient-to-r from-transparent via-white/50 to-transparent pointer-events-none" />

        {/* Both 'CSM' and '14' share the exact same Inter typeface, weight (800), and tracking */}
        <span className="relative z-10 font-extrabold tracking-[0.2em] text-white select-none whitespace-nowrap transition-transform duration-200 group-hover:scale-[1.02] drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]">
          CSM 14
        </span>

        {/* Subtle orange liquid droplet accent */}
        <div className="absolute bottom-1.5 right-2.5 w-1.5 h-1.5 rounded-full bg-[#f97316]/80 shadow-[0_0_6px_#f97316] group-hover:bg-[#f97316] transition-all" />
      </div>

      {showSubtitle && (
        <span className="mt-1.5 text-[10px] tracking-[0.25em] uppercase text-neutral-400 font-medium">
          Study Materials
        </span>
      )}
    </div>
  );
};
