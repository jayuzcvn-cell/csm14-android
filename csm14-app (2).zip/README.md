# CSM 14 — Study Materials Controller

Black edition liquid glass web application with custom video matrix controller, mobile ergonomics, and audio synthesizer feedback.

---

## 🚀 Quick Start & Installation

### Prerequisites
Make sure you have **Node.js** (version 18, 20, or newer) installed on your computer.  
If you don't have Node.js, download it free from [nodejs.org](https://nodejs.org/).

---

### Step 1: Unzip the File
Extract `csm14-app.zip` to a folder of your choice on your computer.

### Step 2: Open Terminal / Command Prompt
Open your terminal (Terminal on Mac/Linux, PowerShell or Command Prompt on Windows) and navigate into the unzipped folder:
```bash
cd path/to/csm14-app
```

### Step 3: Install Dependencies
Run the install command to download all required packages:
```bash
npm install
```
*(Or if you use Bun or pnpm: `bun install` or `pnpm install`)*

### Step 4: Run the Development Server
Start the local server by running:
```bash
npm run dev
```

### Step 5: Open in Your Browser
Once the server starts, open your browser and go to:
```
http://localhost:3000
```

---

## 📦 Production Build
To create a high-performance production build ready for deployment (Vercel, Netlify, Cloud Run, Firebase, etc.):
```bash
npm run build
```
The compiled static assets will be created in the `dist/` directory.

---

## 📱 How to Install on Mobile as an App
You can install this directly onto your smartphone's home screen:
- **iPhone / iPad (Safari)**:
  1. Open the app URL in Safari.
  2. Tap the **Share** button (box with an arrow pointing up at the bottom).
  3. Scroll down and tap **"Add to Home Screen"**.
- **Android (Chrome)**:
  1. Open the app URL in Chrome.
  2. Tap the **three dots (⋮)** in the top right corner.
  3. Tap **"Install App"** or **"Add to Home screen"**.

---

## 🛠 Features Included
- **Liquid Glass Theme**: Pure black (`#000000`) background with refractive glass cards and radiant orange glow highlights.
- **8 Configured Video Buttons**: Code numbers `11`, `12`, `21`, `22`, `31`, `32`, `41`, `42` mapped to your study stream links.
- **Top Menu Drawer**: Custom video link editor, metronome tempo timer, and audio haptics.
- **In-App Theater Player**: Watch YouTube streams directly inside the app without leaving.
